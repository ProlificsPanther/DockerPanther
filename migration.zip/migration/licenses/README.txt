Legal Notice
------------

migration.jar and Migration_Project.zip, including all source code and 
documentation for each are licensed to you by Prolifics, Inc., under the
MIT License provided in the file MIT-LICENSE-Migration.txt.

The following JAR file is redistributed under the Apache License Version 2.0,
a copy of which is provided in the file, Apache-License-2.0.txt:

commons-io-2.5.jar

Bootstrap components are redistributed under the MIT License provided by the
file, MIT-LICENSE-Bootstrap.txt.

JQuery components are redistributed under the MIT License provided by the file,
MIT-LICENSE-JQuery.txt

JQuery-ui components are redistributed under the MIT License provided by the
file, MIT-LICENSE-JQuery-ui.txt

JQuery Datatables components are redistributed under the MIT License provided
by the file, MIT-LICENSE-DataTables.txt

JQuery Datepicker components are redistributed under the MIT License provided
by the file, MIT-LICENSE-Datepicker.txt

JQuery Timepicker components are redistributed under the MIT License provided
by the file, MIT-LICENSE-Timepicker.txt

JQuery SmartMenus components are redistributed under the MIT License provided
by the file, MIT-LICENSE-SmartMenus.txt

bootstrap-treeview contains the copyright, Copyright 2013 Jonathan Miles, and
is redistributed under the Apache 2.0 license.
